
const config = { backendEndpoint: "http://13.127.218.50:8082" };


// http://13.127.218.50:8081/frontend/
// http://13.127.218.50:8081/frontend/pages/adventures/?city=bengaluru
// http://13.127.218.50:8081/frontend/pages/adventures/detail?city=bengaluru
// http://13.127.218.50:8081/frontend/pages/adventures/reservations
// frontend/pages/adventures/reservations

export default config;
